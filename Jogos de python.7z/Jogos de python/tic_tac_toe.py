import random

# Definindo o inicio do jogo
print('Iniciando o jogo do TIC-TAC-TOE\n')

# Definindo as variáveis básicas do jogo
a = 1
b = 2
c = 3
d = 4
e = 5
f = 6
g = 7
h = 8
i = 9

# Criando a malha do jogo da velha
def malha():
    print('+-------+-------+-------+')
    print('|       |       |       |')
    print(f'|   {a}   |   {b}   |   {c}   |')
    print('|       |       |       |')
    print('+-------+-------+-------+')
    print('|       |       |       |')
    print(f'|   {d}   |   {e}   |   {f}   |')
    print('|       |       |       |')
    print('+-------+-------+-------+')
    print('|       |       |       |')
    print(f'|   {g}   |   {h}   |   {i}   |')
    print('|       |       |       |')
    print('+-------+-------+-------+')

# Exibe a malha inicial
malha()

# Lista com as jogadas possíveis
jogadas_possiveis = [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Explicação para o jogador
print('O computador joga com O e você joga com X, apenas escolha um dos números que aparecerá na tela e se divirta!')

# Função que verifica as condições de vitória
def verifica_vitoria():
    # Linhas
    if a == b == c == 'X' or d == e == f == 'X' or g == h == i == 'X':
        print('Vitória do usuário!')
        return True
    if a == b == c == 'O' or d == e == f == 'O' or g == h == i == 'O':
        print('Vitória do computador!')
        return True

    # Colunas
    if a == d == g == 'X' or b == e == h == 'X' or c == f == i == 'X':
        print('Vitória do usuário!')
        return True
    if a == d == g == 'O' or b == e == h == 'O' or c == f == i == 'O':
        print('Vitória do computador!')
        return True

    # Diagonais
    if a == e == i == 'X' or c == e == g == 'X':
        print('Vitória do usuário!')
        return True
    if a == e == i == 'O' or c == e == g == 'O':
        print('Vitória do computador!')
        return True

    return False

# Função que faz a jogada do computador
def jogada_da_maquina():
    global a, b, c, d, e, f, g, h, i
    escolha_computador = random.choice(jogadas_possiveis)

    # Atualiza a posição escolhida pelo computador
    if escolha_computador == 1:
        a = 'O'
    elif escolha_computador == 2:
        b = 'O'
    elif escolha_computador == 3:
        c = 'O'
    elif escolha_computador == 4:
        d = 'O'
    elif escolha_computador == 5:
        e = 'O'
    elif escolha_computador == 6:
        f = 'O'
    elif escolha_computador == 7:
        g = 'O'
    elif escolha_computador == 8:
        h = 'O'
    elif escolha_computador == 9:
        i = 'O'

    print(f'O computador escolheu {escolha_computador}')
    malha()

# Função que realiza a jogada do usuário
def jogada_do_usuario():
    global a, b, c, d, e, f, g, h, i
    print(f'Jogadas possíveis: {jogadas_possiveis}')
    escolha_usuario = int(input('Escolha e digite um dos números acima: '))

    # Verifica se a escolha do usuário é válida
    if escolha_usuario in jogadas_possiveis:
        if escolha_usuario == 1:
            a = 'X'
        elif escolha_usuario == 2:
            b = 'X'
        elif escolha_usuario == 3:
            c = 'X'
        elif escolha_usuario == 4:
            d = 'X'
        elif escolha_usuario == 5:
            e = 'X'
        elif escolha_usuario == 6:
            f = 'X'
        elif escolha_usuario == 7:
            g = 'X'
        elif escolha_usuario == 8:
            h = 'X'
        elif escolha_usuario == 9:
            i = 'X'

        jogadas_possiveis.remove(escolha_usuario)
        malha()
    else:
        print('Escolha inválida! Tente novamente.')

# Início da primeira jogada do computador
print('A primeira jogada sempre é da máquina!')

# Loop do jogo
while not verifica_vitoria():
    jogada_da_maquina()

    if verifica_vitoria():
        break

    jogada_do_usuario()

    if verifica_vitoria():
        break
