#importando a biblioteca para randomicos
import random
#importando a biblioteca de tempo
import time


#variaveis para contar as vitorias dos usuarios
cont_us = 0
cont_pc = 0

 #Titulo do progrmaa
print('PEDRA - PAPEL - TESOURA -> Melhor de três')

 #pergunta inicial de jogo
escolha = input('Você quer jogar? (sim ou nao)')

 #laço de repetição para o jogo não acabar
while escolha == 'sim' or escolha == 'SIM':

#Monta uma lista com as jogadas possiveis
 jogadas_possiveis = ['pedra','papel','tesoura']
 
 #Pergunta qual a jogada do usuario
 escolha_usuario = int(input('Qual sua jogada? (1 - pedra 2 - papel 3 - tesoura)'))
 
 #Faz uma estrutura condicional para para a escolha do usuario
 if escolha_usuario == 1: 
 
     escolha_usuario = jogadas_possiveis[0]
 
 elif escolha_usuario == 2: 
 
     escolha_usuario = jogadas_possiveis[1] 
 
 elif escolha_usuario == 3: 
 
     escolha_usuario = jogadas_possiveis[2]
 
 #Faz a escolha do computador
 escolha_computador = random.choice(jogadas_possiveis)

 print('JO')
 time.sleep(1)
 print('KEM')
 time.sleep(1)
 print('PO')
 time.sleep(1)

 
 print(F'O usuario jogou: {escolha_usuario}')
 print(F'O computador jogou: {escolha_computador}')
 
 #Faz uma estrutura condicional para finalizar o jogo
 if escolha_usuario == 'pedra' and escolha_computador == 'pedra' : 
 
     print(F'EMPATE DE PEDRAS!')
 
 elif escolha_usuario == 'papel' and escolha_computador == 'papel' : 
 
     print(F'EMPATE DE PAPEIS!')
 
 elif escolha_usuario == 'tesoura' and escolha_computador == 'tesoura' : 
 
     print(F'EMPATE DE TESOURAS!')
 
 elif escolha_usuario == 'pedra' and escolha_computador == 'papel' : 
 
     print(F'COMPUTADOR VENCE')

     cont_pc = cont_pc + 1
 
 elif escolha_usuario == 'papel' and escolha_computador == 'pedra' :
      
     print(F'USUARIO VENCE')

     cont_us = cont_us + 1
 
 elif escolha_usuario == 'papel' and escolha_computador == 'tesoura' : 
 
     print(F'COMPUTADOR VENCE')

     cont_pc = cont_pc + 1
 
 elif escolha_usuario == 'tesoura' and escolha_computador == 'papel' :
      
     print(F'USUARIO VENCE')

     cont_us = cont_us + 1
 
 elif escolha_usuario == 'tesoura' and escolha_computador == 'pedra' : 
 
     print(F'COMPUTADOR VENCE')

     cont_pc = cont_pc + 1
 
 elif escolha_usuario == 'pedra' and escolha_computador == 'tesoura' :
      
     print(F'USUARIO VENCE')

     cont_us = cont_us + 1

     if cont_us == 3:
         
         print(F'O usuario venceu!')

     elif cont_pc == 3:
         
         print(F'O COMPUTADOR VENCEU VOCE!') 
 
 #pergunta final para repetição do programa
 escolha = input('Você quer jogar novamente? (sim ou nao)')
 
 if escolha == 'nao' or escolha == 'NAO':
     print('O jogador humano desistiu do jogo, FRACO!!!')