

def verifica_palindromo(palavra):

    palavra_minuscula = palavra.lower()

    palavra_reversa = palavra_minuscula[::-1]

    if palavra == palavra_reversa:
        print(F'Essa palavra é uma palindromo')
    else:
        print(F'Essa palavra não é um palindromo')

Palavra_Usuario = input("Digite uma palavra: ")

verifica_palindromo(Palavra_Usuario)
