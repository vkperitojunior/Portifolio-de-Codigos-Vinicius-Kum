import random

numero_inteiro = int(input("Digite um numero inteiro para saber se ele é primo: "))

if numero_inteiro == 2:
   print(F'Seu numero é Primo!')

if numero_inteiro > 1:

    if numero_inteiro % 2 != 0:

          print(F'Seu numero é Primo!')
                
    else:
                print(F'Seu numero não é Primo!')


else: 
                print(F'Seu numero não é Primo!')