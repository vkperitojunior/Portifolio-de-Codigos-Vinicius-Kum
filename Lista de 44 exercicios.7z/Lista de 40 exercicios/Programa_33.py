import re  # Importando a biblioteca de expressões regulares

# Recebe a senha digitada
Senha_Digitada = input('Digite uma senha contendo pelo menos um numero, e um caracter maiusculo e minusculo: ')

# Inicializando as variáveis para a verificação
Quantidade_Caracteres = len(Senha_Digitada)
Verifica_Letras_Maiusculas = False
Verifica_Letras_Minúsculas = False
Verifica_Numeros = False
Verifica_Especiais = False

# Percorre a senha para verificar as condições
for char in Senha_Digitada:
    if char.islower():
        Verifica_Letras_Minúsculas = True  # Encontrou letra minúscula
    elif char.isupper():
        Verifica_Letras_Maiusculas = True  # Encontrou letra maiúscula
    elif char.isdigit():
        Verifica_Numeros = True  # Encontrou número
    elif char in "$@%!":  # Verifica caracteres especiais
        Verifica_Especiais = True

# Verificando as condições da senha
if Quantidade_Caracteres >= 8:
    if Verifica_Letras_Maiusculas and Verifica_Letras_Minúsculas:
        if Verifica_Numeros:
            if Verifica_Especiais:
                print('SENHA ÓTIMA') 
            else:
                print('Deve-se ter caracteres especiais na senha') 
        else:
            print('Deve-se ter numeros na senha')  
    else:
        print('Deve-se ter letras maiúsculas e minúsculas na senha')
else:
    print('Tente novamente, 8 caracteres é o minimo permitido!')
