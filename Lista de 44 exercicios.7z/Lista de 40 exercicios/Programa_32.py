print(F'Sum AVG ')

lista_nr = []
lista_pr = []

i = 0
decisao = 0

while decisao != 1:
     i += 1
     decisao = int(input('0 continua e 1 para: '))
     if decisao == 1:
       break
     numero_digitado = float(input(F'Digite o numero {i}: '))
     lista_nr.append(numero_digitado)
     if numero_digitado % 2 == 0:
         lista_pr.append(numero_digitado)

print(F'Dentre a lista digitada, os numeros pares foram: {lista_pr}')