salario_bruto = float(input("Digite seu salario: "))

aumento_bruto = (salario_bruto*15)/100
salario_final = salario_bruto+aumento_bruto

print(F'Seu salario pode ter uma aumento de ate 15%, passando de {salario_bruto} para {salario_final}')