numero_1 = int(input('Digite o numero 1: '))
numero_2 = int(input('Digite o numero 2: '))
numero_3 = int(input('Digite o numero 3: '))

if numero_1 > numero_2 and numero_1 > numero_3:
    print(F'Seu maior numero é o numero 1: {numero_1}')
elif numero_2 > numero_1 and numero_2 > numero_3:
    print(F'Seu maior numero é o numero 2: {numero_2}')
elif numero_3 > numero_1 and numero_3 > numero_2:
    print(F'Seu maior numero é o numero 3: {numero_3}')