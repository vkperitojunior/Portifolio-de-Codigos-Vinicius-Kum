print(F'Contagem regressiva com numero inteiro possitivo')

numero = int(input('Digite o numero para fazer a contagem: '))

i=0

if numero < 0:
    print(F'Numero não é positivo, tente novamente')
else:
    while(i <= numero):
      print(F"Numero: {i}")
      i += 1


