import random

numero_inteiro = int(input("Digite ate aonde você gostaria de ver os primos: "))

i = 0

while i <= numero_inteiro:

    if i == 2:
        print(F'Numero: 2')

    if i > 1:

        if i % 2 != 0:

              print(F'Numero: {i}')
                    
    #     else:
    #                 print(F'Seu numero não é Primo!')


    # else: 
    #                 print(F'Seu numero não é Primo!')

    i += 1