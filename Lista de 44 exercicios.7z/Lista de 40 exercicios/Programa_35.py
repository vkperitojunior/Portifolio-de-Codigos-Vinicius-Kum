# Recebe a quantidade de segundos do usuário
qtd_segundos = int(input('Coloque uma quantidade de segundos para serem convertidos em horas, minutos e segundos: '))

# Inicializando variáveis
qtd_minutos = 0
qtd_horas = 0
qtd_dias = 0

# Convertendo segundos para minutos
while qtd_segundos >= 60:
    qtd_segundos -= 60
    qtd_minutos += 1

# Convertendo minutos para horas
while qtd_minutos >= 60:
    qtd_minutos -= 60
    qtd_horas += 1

# Convertendo horas para dias
while qtd_horas >= 24:
    qtd_horas -= 24
    qtd_dias += 1

# Exibindo o resultado
print(f'Com os segundos digitados, temos: {qtd_dias} dias, {qtd_horas} horas, {qtd_minutos} minutos e {qtd_segundos} segundos.')
