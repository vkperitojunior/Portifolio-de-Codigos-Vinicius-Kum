altura_cm = int(input("Digite sua altura em cm: "))
peso_kg = float(input("Digite seu peso em kg: "))
sexo = int(input('Digite seu sexo, 1 para feminino e 2 para masculinho: '))

if sexo == 1:
    imc = peso_kg/(altura_cm**2)
    print(F'Seu IMC é: {imc}')

    if imc < 18.5:
        print(F'Baixo Peso')
    elif imc > 18.5 and imc < 24.9 :
        print(F'Peso Adequado')
    elif imc >= 25.0 and imc < 29.9 :
        print(F'Sobrepeso')
    elif imc > 30.0 and imc < 34.9 :
        print(F'Obesidade grau 1')
    elif imc > 35.0 and imc < 39.9 :
        print(F'Obesidade grau 2')
    elif imc >= 40.0 :
        print(F'Obesidade grau 3')

elif sexo == 2:
    imc = peso_kg/altura_cm**2
    print(F'Seu IMC é: {imc}')

    if imc < 18.5:
        print(F'Baixo Peso')
    elif imc > 18.5 and imc < 24.9 :
        print(F'Peso Adequado')
    elif imc >= 25.0 and imc < 29.9 :
        print(F'Sobrepeso')
    elif imc > 30.0 and imc < 34.9 :
        print(F'Obesidade grau 1')
    elif imc > 35.0 and imc < 39.9 :
        print(F'Obesidade grau 2')
    elif imc >= 40.0 :
        print(F'Obesidade grau 3')