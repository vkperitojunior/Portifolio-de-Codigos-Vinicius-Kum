Frase_Usuario = input("Digite uma frase: ")
Palavra_Antiga_Usuario = input("Digite a antiga palavra: ")
Palavra_Nova_Usuario = input("Digite a nova palavra: ")

frase_corrigida = Frase_Usuario.replace(Palavra_Antiga_Usuario,Palavra_Nova_Usuario)

print(F'A frase corrigida ficaria -----> {frase_corrigida}')


# https://www.hashtagtreinamentos.com/string-no-python