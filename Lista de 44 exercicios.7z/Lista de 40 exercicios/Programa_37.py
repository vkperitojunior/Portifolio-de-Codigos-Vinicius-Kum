ano_nascimento = int(input('Qual seu ano de nascimento: '))

idade = 2024 - ano_nascimento

print(F'Sua idade é: {idade}')