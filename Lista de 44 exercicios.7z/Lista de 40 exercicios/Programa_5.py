numero_a_conferir = int(input('Numero para conferir: '))

if numero_a_conferir % 2 == 0:
    print(F'Seu numero {numero_a_conferir} é par')
else:
    print(F'Seu numero {numero_a_conferir} é impar')


