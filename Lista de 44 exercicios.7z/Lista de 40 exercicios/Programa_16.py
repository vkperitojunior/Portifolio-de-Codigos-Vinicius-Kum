frase = input('Escreva uma frase: ')

cont_cr = len(frase)

print(F'A frase que você digitou tem {cont_cr} caracteres, contando com espaços')