media = int(input('Qual a sua media: '))

if media >= 7:
    print(F'APROVADO')
elif media >= 5 and media <= 6.9:
    print(F'RECUPERAÇÃO')
else:
    print(F'REPROVADO')


