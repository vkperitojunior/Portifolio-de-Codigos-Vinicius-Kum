def transformar_vogais_maiusculas(texto):
    # Definindo as vogais
    vogais = "aeiouAEIOU"
    
    # Usando list comprehension para transformar as vogais em maiúsculas
    texto_transformado = ''.join([char.upper() if char in vogais else char for char in texto])
    
    print(F'{texto_transformado}')

# Testando a função
texto = input('Digite uma frase: ')
transformar_vogais_maiusculas(texto)