print(F'Sum AVG ')

lista_nr = []

i = 0
decisao = 0
soma = 0

while decisao != 1:
     i += 1
     decisao = int(input('0 continua e 1 para: '))
     if decisao == 1:
       break
     numero_digitado = float(input(F'Digite o numero {i}: '))
     lista_nr.append(numero_digitado)
     soma += numero_digitado

media = soma/i

print(F'A media final de todos os numeros é: {media}')