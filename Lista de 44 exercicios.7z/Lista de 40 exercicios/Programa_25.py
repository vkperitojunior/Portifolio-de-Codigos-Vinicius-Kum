preco_alcool = float(input('Qual o preço do alcool: '))
preco_gasolina = float(input('Qual o preço do gasolina: '))

proporcao_gasolina=(70*preco_gasolina)/100

if preco_alcool <= proporcao_gasolina:
    print(F'No momento vale a pena a compra do alcool')
else:
    print(F'No momento vale a pena a compra da gasolina')   