Frase_Usuario = input("Digite uma frase: ")

frase_maiuscula = Frase_Usuario.upper()

quant_vg1 = frase_maiuscula.count('A')
quant_vg2 = frase_maiuscula.count('E')
quant_vg3 = frase_maiuscula.count('I')
quant_vg4 = frase_maiuscula.count('O')
quant_vg5 = frase_maiuscula.count('U')

print(F'A vogal A aparece {quant_vg1} vezes')
print(F'A vogal E aparece {quant_vg2} vezes')
print(F'A vogal I aparece {quant_vg3} vezes')
print(F'A vogal O aparece {quant_vg4} vezes')
print(F'A vogal U aparece {quant_vg5} vezes')
