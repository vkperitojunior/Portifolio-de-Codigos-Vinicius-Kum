print('SEQUÊNCIA DE FIBONACCI')

numero_max = int(input("Qual o número máximo da sequência? "))

# Inicializando a sequência de Fibonacci com os dois primeiros números
numeros_em_sequencia = [1, 1]

# Iniciando a partir do terceiro número (índice 2)
i = 2  # A partir do índice 2, porque já temos 2 elementos (1 e 1) que são padroes 

# Gerando os números da sequência até o número máximo
while numeros_em_sequencia[i-1] <= numero_max:
    numero_atual = numeros_em_sequencia[i-1] + numeros_em_sequencia[i-2]
    numeros_em_sequencia.append(numero_atual)
    i += 1

# Exibindo a sequência final
print(f'A lista final ficou: {numeros_em_sequencia}')