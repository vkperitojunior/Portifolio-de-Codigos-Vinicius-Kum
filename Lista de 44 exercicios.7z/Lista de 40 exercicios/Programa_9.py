print(F'Identificador de anos bissextos')
ano = int(input('Digite o ano que você deseja saber: '))

if ano % 4 == 0:
    print(F'O ano de {ano} é um ano bissexto')
else:
    print(F'O ano de {ano} não é um ano bissexto')