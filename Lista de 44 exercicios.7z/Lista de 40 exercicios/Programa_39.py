import random

numero_de_numeros = random.randint(0,10000)
i=0

while i < numero_de_numeros:
    i += 1
    numero = random.randint(0,1000000000)
    print(F'Numero {i}: {numero}')