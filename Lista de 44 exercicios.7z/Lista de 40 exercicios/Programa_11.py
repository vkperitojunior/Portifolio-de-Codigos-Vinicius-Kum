#Perguntando a tabudada de que numero ele precisa
n_tabuada = int(input('Qual numero você deseja para vizualizar a tabuada? '))

#contruindo um contador para o while
cont_tb = 0 

# construindo a tabuada
while cont_tb <= 10:

    resultado = n_tabuada * cont_tb
    print(F'{cont_tb} x {n_tabuada} = {resultado}')

    cont_tb += 1
