def mensagem_sistematica(nome):
    print(F'Bem vindo ao nosso sistema senhor(a) {nome}')

nome_usuario = input("Qual seu nome: ")

mensagem_sistematica(nome_usuario)