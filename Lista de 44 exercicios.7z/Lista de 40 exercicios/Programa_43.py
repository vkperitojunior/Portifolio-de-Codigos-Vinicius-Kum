
numero_p_fatorial = int(input("Digite o numero para fazer fatorial: "))

i = 1

numero_final = 1

while i <= numero_p_fatorial:

    numero_final = numero_final * i

    i += 1

print(F'Numero final do fatorial é: {numero_final}')