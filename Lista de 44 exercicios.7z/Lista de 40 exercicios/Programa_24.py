import math

print(F'Calculadora de bhaskara: ')
a = float(input('Digite o a: '))
b = float(input('Digite o b: '))
c = float(input('Digite o c: '))

delta = (b**2) - 4*a*c
raiz_delta = math.sqrt(delta)

if delta > 0:
    raiz_1=(-b+raiz_delta)/2*a
    raiz_2=(-b-raiz_delta)/2*a
    vertice_x=-b/(4*a)
    vertice_y=-delta/(4*a)
    print(F'Nos temos duas raizes, sendo X1 = {raiz_1}, X2 = {raiz_2}, delta = {delta}, raiz quadrada do delta = {raiz_delta}, e vertice = ({vertice_x},{vertice_y})')
elif delta == 0:
    raiz_1=(-b+raiz_delta)/2*a
    raiz_2=(-b-raiz_delta)/2*a
    vertice_x=-b/(4*a)
    vertice_y=-delta/(4*a)
    print(F'Nos temos apenas uma raiz, sendo X = {raiz_1}, X = {raiz_2}, delta = {delta}, raiz quadrada do delta = {raiz_delta}, e vertice = ({vertice_x},{vertice_y})')
elif delta < 0:
    print(F'Não temos raizes porque o delta é menor que zero')