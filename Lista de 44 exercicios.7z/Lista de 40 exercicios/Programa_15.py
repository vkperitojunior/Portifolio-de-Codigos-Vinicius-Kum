print(F'Armazem da Esquina Ao Lado')
print(F'[]')
print(F'Digite tres produtos para comparar o preço: ')

produtos = ()
precos = ()

lista_pd = list(produtos)
lista_pr = list(precos)

i=0

while i <= 2:
 
     produto = input(F'Digite o produto {i+1}: ')
     lista_pd.append(produto)
     preco = float(input(F'Digite o valor do produto {i+1} separado por ponto: '))
     lista_pr.append(preco)
     i += 1

preco_max = max(lista_pr)
elemento_max = lista_pr.index(preco_max)
nome_max = lista_pd[elemento_max]

print(F'O nome do produto mais caro é: {nome_max}, seu valor é: {preco_max} e sua posicao é: {elemento_max}')

produtos = tuple(lista_pd)
precos = tuple(lista_pr)
