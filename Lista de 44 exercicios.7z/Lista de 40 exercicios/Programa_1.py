nome_usuario = input('Qual o seu nome? ')
idade_usuario = int(input('Qual sua idade? '))

print(F'Olá {nome_usuario}! Bem Vindo ao nosso sistema, e pelo que consta em suas informações, você tem {idade_usuario} anos de idade!')
