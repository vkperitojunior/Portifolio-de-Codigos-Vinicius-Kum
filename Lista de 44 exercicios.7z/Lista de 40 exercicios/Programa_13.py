i=0
numeros_selecionados = []

# construindo a lista
while i <= 4:
    i += 1
    numero = int(input(F'Digite o numero {i}: '))
    numeros_selecionados.append(numero)


numeros_selecionados.reverse()

print(F'{numeros_selecionados}')


