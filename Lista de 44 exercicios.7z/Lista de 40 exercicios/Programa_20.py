def listagem_de_numeros():
    decisao=1
    i=1
    listagem_de_numeros=[]
    while decisao == 1:
        decisao = int(input("0 para parar e 1 para continuar: "))
        if decisao == 0:
            break
        numero_a_adicionar = float(input(F'Numero {i}: '))
        listagem_de_numeros.append(numero_a_adicionar)
        i += 1
    
    print(F'O maior numero é: {max(listagem_de_numeros)}')


listagem_de_numeros()
