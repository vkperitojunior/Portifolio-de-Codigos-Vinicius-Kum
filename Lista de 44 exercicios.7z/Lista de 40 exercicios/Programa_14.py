palavra = ''
lista_palavras = []

print(F'Dicionario de palavras, se quiser filtrar, digite "acabou"')

# construindo a lista
while palavra != 'Acabou' or palavra != 'ACABOU' or palavra != 'acabou' :

    palavra = input('Qual a palavra que você quer adicionar? -> ')

    if palavra == 'Acabou' or palavra == 'ACABOU' or palavra == 'acabou':
        break

    lista_palavras.append(palavra)

cont_pl = 0

# Laço for para percorrer cada palavra da lista
for palavra in lista_palavras:
    if len(palavra) > 5:
        cont_pl += 1 

print(F'Existem {cont_pl} palavras em seu dicionario que tem mais de 5 letras')