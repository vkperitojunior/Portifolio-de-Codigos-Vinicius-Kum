print('Lista sem duplicação!')

# Lista para armazenar os números digitados
lista_cp = []

# Variáveis de controle
i = 0
decisao = 0

# Função para remover duplicados usando set
def remover_duplicatas(lista):
    # Remover duplicados e garantir que a lista seja ordenada
    lista_sem_duplicados = list(set(lista))
    print(f"Lista sem duplicados: {lista_sem_duplicados}")

# Loop para capturar números do usuário
while True:  # Esse loop vai continuar até o usuário decidir parar
    i += 1
    # Perguntar ao usuário se ele quer continuar ou parar
    decisao = int(input('Digite 0 para continuar e 1 para parar: '))
    if decisao == 1:
        break  # Se o usuário digitar 1, o loop vai parar
    elif decisao == 0:
        numero_digitado = float(input(f'Digite o número {i}: '))  # Solicitar um número
        lista_cp.append(numero_digitado)  # Adicionar à lista
    else:
        print('Entrada inválida. Digite 0 para continuar ou 1 para parar.')  # Caso a opção não seja 0 nem 1

# Chama a função para remover duplicados e exibir a lista final
remover_duplicatas(lista_cp)


# https://awari.com.br/lista-python-remova-duplicatas-e-otimize-seu-codigo/#:~:text=1.-,Utilizando%20o%20m%C3%A9todo%20set(),que%20n%C3%A3o%20permite%20elementos%20duplicados.