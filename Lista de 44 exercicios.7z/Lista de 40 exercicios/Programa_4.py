numero_1 = int(input('Digite o numero 1: '))
numero_2 = int(input('Digite o numero 2: '))

media = (numero_1 + numero_2) / 2

print(F'A média dos dois numero é: {media}')