import random

print(F"Bem vindo ao sorteio virtual de numeros")

x = int(input('Digite o numero minimo: '))
y = int(input('Digite o numero maximo: '))

comando = ''

while comando != 0:


    sorteio = random.randint(x, y)

    print(F"O numero sorteado foi: {sorteio}")

    palavra = input('Quer continuar digite 1, quer para digite 0? -> ')

    if comando == 0:
        break
