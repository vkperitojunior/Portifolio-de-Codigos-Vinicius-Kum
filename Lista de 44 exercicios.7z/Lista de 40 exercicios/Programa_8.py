valor_produto = float(input('Qual o valor do produto: '))

if valor_produto >= 100:
    valor_final=(10/100)*valor_produto
    valor_final=valor_produto-valor_final
    print(F'O valor final teve 10% de desconto por ser 100 ou mais, valor final: {valor_final}')
else:
    valor_final=(5/100)*valor_produto
    valor_final=valor_produto-valor_final
    print(F'O valor final teve 5% de desconto por ser comum, valor final: {valor_final}')


