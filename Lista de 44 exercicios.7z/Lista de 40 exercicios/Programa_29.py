print(F'Lista de produtos e preços: ')

lista_pd = []
lista_pr = []

i = 0
decisao = 0

while decisao != 1:
     i += 1
     decisao = int(input('0 continua e 1 para: '))
     if decisao == 1:
       break
     produto = input(F'Digite o produto {i}: ')
     lista_pd.append(produto)
     preco = float(input(F'Digite o valor do produto {i} separado por ponto: '))
     lista_pr.append(preco)

preco_max = max(lista_pr)
elemento_max = lista_pr.index(preco_max)
nome_max = lista_pd[elemento_max]
soma_valores = sum(lista_pr)

print(F'O nome do produto mais caro é: {nome_max}, seu valor é: {preco_max} e sua posicao é: {elemento_max}')
print(F'A soma de todos os valores é: {soma_valores}')
