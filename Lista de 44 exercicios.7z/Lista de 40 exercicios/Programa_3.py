temperatura_inicial = int(input('Digite a temperatura em celsiuls: '))

temperatura_convertida = (temperatura_inicial * 9/5) + 32

print(F'A temperatura em Farenheight é: {temperatura_convertida}')
