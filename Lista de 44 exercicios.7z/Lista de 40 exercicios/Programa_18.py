Frase_Usuario = input("Digite uma frase: ")
Palavra_Usuario = input("Digite uma palavra: ")

quantidade_de_ocorrencias = Frase_Usuario.count(Palavra_Usuario)

print(F'A palavra que você citou aparece {quantidade_de_ocorrencias} vezes na frase!')
