
print(F'Media de idades, para finalizar um bloco digite um numero negativo')


idade=0
i=0
soma_idades=0

# construindo a tabuada
while idade >= 0:

    i += 1

    #Perguntando a tabudada de que numero ele precisa
    idade = int(input(F'A idade {i}: '))

    soma_idades += idade

media = soma_idades / i

print(F'A media final das idade é: {media}')
