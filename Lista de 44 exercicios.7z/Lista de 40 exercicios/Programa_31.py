Palavra_Usuario = input("Digite uma palavra: ")

palavra_reversa = Palavra_Usuario[::-1]

print(F'A palavra ao contrário ficaria: {palavra_reversa}')
