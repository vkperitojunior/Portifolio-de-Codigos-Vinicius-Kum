numero_1 = int(input('Digite o numero 1: '))
numero_2 = int(input('Digite o numero 2: '))

print(F'{numero_1+numero_2}')
print(F'{numero_1-numero_2}')
print(F'{numero_1*numero_2}')
print(F'{numero_1/numero_2}')