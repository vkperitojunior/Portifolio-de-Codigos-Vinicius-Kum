
from datetime import datetime

hora_atual = datetime.now()
print(hora_atual)